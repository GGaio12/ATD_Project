function [Emin, i] = getEmin(f)
%
    % Note The function 'sum(abs(y(:,i)).^2)' returns the energy value of the interval 'i'
    Es = [sum(abs(f(:,1:5)).^2)];

    i = 6;
    Emin = sum(abs(f(:,i:i+3)).^2);
    meansDifs = mean(abs(Es(1:end-1) - Es(2:end))/2);

    while or(0, any(Emin < 1.01*(mean(Es) + meansDifs)))
        Es = [Es(2:end), Emin(:,1)];
        i = i + 1;
        Emin = sum(abs(f(:,i:i+3)).^2);
        meansDifs = mean(abs(Es(1:end-1) - Es(2:end))/2);
    end
    Emin = Emin(:,1);
end